This library for the ILI9340 is no longer being developed, you can use the ILI9341 code as a drop-in replacement!

https://github.com/adafruit/Adafruit_ILI9341
